package dream11.api.selectmatch;

	public class CricketTeams {
	   public enum SunriserHyderabad{
				BhuvneshwarKumar(1,"Bhuvneshwar Kumar",55), RahulTripathi(2,"Rahul Tripathi",30),
				AbhishekSharma(3,"Abhishek sharma",35),
				TNatarajan(4,"T Natarajan",35),HarryBrook(5,"Harry Brook",55),
				AidenMarkram(6,"Aiden Markram",75),MayankMarkande(7,"Mayank Markande",40),
				NitishKumarareddy(8,"Nitish Kumar Reddy",75),GlennPhillips(9,"Glenn Phillips",65),
				UpendraSinghYadav(10,"Upendra Singh Yadav",50),
				UrmanMalik(11,"Urman Malik",25);
			
				private int serialno;
				private String name;
				private	int score;
					public int getSerialno() {
				return serialno;
			}
					public void setSerialno(int serialno) {
				this.serialno = serialno;
			}
					public String getName() {
				return name;
			}
					public void setName(String name) {
				this.name = name;
			}
					public int getScore() {
				return score;
			}
					public void setScore(int score) {
				this.score = score;
			}
			
					SunriserHyderabad(int serialno,String name ,int score)
			{
			 this.serialno=serialno;
			 this.name=name;
			 this.score=score;
			}
			
		}

	     public enum DelhiCapital{
	    	   DavidWarner(1,"David Warner",80),RovmanPowell(2,"Rovman Powell",45),
	    	   MitchellMarsh(3,"Mitchell Marsh",65),RipalPatel(4,"Ripal Patel",55),
	    	   VickyOstwal(5,"Vicky Ostwal",20),
	    	   AmanKhan(6,"Aman Khan",70),IshantSharma(7,"Ishant Sharma",40),
	    	   ManishPandey(8,"Manish Pandey",75),PrithviShaw(9,"Prithvi Shaw",35),
	    	   axarPatel(10,"axar Patel",40),
	    	   YashDhull(11,"Yash Dhull",58);
	    	 		int serialno;
	    	 		int score;
	    	 		String name;
	    	 		public int getSerialno() {
				return serialno;
			}
	    	 		public void setSerialno(int serialno) {
				this.serialno = serialno;
			}
	    	 		public String getName() {
				return name;
			}
	    	 		public void setName(String name) {
				this.name = name;
			}
	    	 		public int getScore() {
				return score;
			}
	    	 		public void setScore(int score) {
				this.score = score;
			}
			 
	    	 		DelhiCapital(int serialno,String name ,int score){
	    	 this.name=name;
	    	 this.serialno=serialno;
	    	 this.score=score;
	    	 
	     }
	    	 
	    	 
	     }
	     public enum RoyalChallenngers{
	    	 ViratKohli(1,"Virat Kohli",55),DavidWilley(2,"David Willey",40),GlennMaxwell(3,"Glenn Maxwell",70),
	    	 MahipalLomror(4,"Mahipal Lomror",60),AkashDeep(5,"Akash Deep",20),
	    	 KarnSharma(6,"Karn Sharma",60),WayneParnell(7,"Wayne Parnell",60),
	    	 RajanLumar(8,"Rajan Kumar",40),HarshalSharma(9,"Harshal Sharma",60),AvinashSingh(10,"Avinash Singh",40),
	    	 FinnAllen(11,"FinnAlllen",65);
	    	 
	    	 	private int serialno;
	    	 	private String name;
	    	 	private int score;
	    	 	public int getSerialno() {
					return serialno;
				}
	    	 		public void setSerialno(int serialno) {
					this.serialno = serialno;
				}
	    	 		public String getName() {
					return name;
				}
	    	 		public void setName(String name) {
					this.name = name;
				}
	    	 		public int getScore() {
					return score;
				}
	    	 		public void setScore(int score) {
					this.score = score;
				}
	    	 		RoyalChallenngers(int serialno,String name ,int score){
	    	 this.name=name;
	    	 this.score=score;
	    	 this.serialno=serialno;
	     
	     }
			
	     
	     }
	     public enum SuperKing{
	    	 	BenStokes(1,"Ben Stokes",60),DevonConway(2,"Devon Conway",30),TusharDeshpande(3,"Tushar Deshpande",55),SimarjeetSingh(4,"Simarjeet Singh",20),DeepakChahar(5,"Deepak Chahar",70),
	    	 	AkashSingh(6,"Akash Singh",65),MSDhoni(7,"MS Dhoni",80),AjinkyaRahanr(8,"Ajinkya Rhane",65),RuturajGaikwad(9,"Ruturaj Gaikwad",75),ShaikRasheed(10,"Shaik Rasheed",65),
	    	 	AjayMandal(11,"Ajay Mandaj",60);
	    	 
	    	 	private int serialno;
	    	 	private String name;
	    	 	private int score;

	    	 		public int getSerialno() {
					return serialno;
				}
	    	 		public void setSerialno(int serialno) {
					this.serialno = serialno;
				}
	    	 		public String getName() {
					return name;
				}
	    	 		public void setName(String name) {
					this.name = name;
				}
	    	 		public int getScore() {
					return score;
				}
	    	 		public void setScore(int score) {
					this.score = score;
				}
	    	 		SuperKing(int serialno,String name, int score){
	    	 this.name=name;
	    	 this.score=score;
	    	 this.serialno=serialno;
	    	
	     }
	     
	     }    

}