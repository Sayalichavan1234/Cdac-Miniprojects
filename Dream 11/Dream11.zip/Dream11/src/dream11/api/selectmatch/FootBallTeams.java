package dream11.api.selectmatch;


public class FootBallTeams {
	
		public enum Liverpool{
			VvavDijk(1,"V van Dijk",40),Adrian(2,"Adrian",60),JoeGomez(3,"Joe Gomez",43),
			JoelMatip(4,"Joel Matip",55),Fabinho(5,"Fabinho",75),
			MSalah(6,"M Salah",40),KNavas(7,"K Navas",30),DJota(8,"D Jota",65),
			CodyGakpo(9,"Cody Gakpo",15),DarwinNunez(10,"Darwin Nunez",35),
			LuisDiaz(11,"Luis Diaz",50);
			
			private int serialno;
			private String name;
			private int score;
			public int getSerialno() {
				return serialno;
			}
			public void setSerialno(int serialno) {
				this.serialno = serialno;
			}
			public String getName() {
				return name;
			}
			public void setName(String name) {
				this.name = name;
			}
			public int getScore() {
				return score;
			}
			public void setScore(int score) {
				this.score = score;
			}
			Liverpool(int serialno,String name ,int score){
				this.name=name;
		    	this.score=score;
		    	this.serialno=serialno;
			}
		}

	    public enum NottinghamForest{
	    	ChrisWood(1,"Chris Wood",20),AndreAyew(2,"Andre Ayew",60),
	    	LyleTaylor(3,"Lyle Taylor",35),Dennis(4,"Dennis",55),
	    	BrennanJohnson(5,"Brennan Johnson",45),
	    	AlexMighten(6,"Alex Mighten",80),SamSurridge(7,"Sam Surridge",60),
	    	TaiwoAwoniyi(8,"Taiwo Awoniyi",30),RemoFreuler(9,"Remo Freuler",70),RyanYates(10,"Ryan Yates",15),
	    	LewisOBrien(11,"Lewis O Brien",70);
	    	
	    	private int serialno;
	    	private String name;
	    	private int score;
	    	NottinghamForest(int serialno,String name , int score){
	    		this.name=name;
		    	this.score=score;
		    	this.serialno=serialno;
	    	}
	    	
	    	
			public int getSerialno() {
				return serialno;
			}
			public void setSerialno(int serialno) {
				this.serialno = serialno;
			}
			public String getName() {
				return name;
			}
			public void setName(String name) {
				this.name = name;
			}
			public int getScore() {
				return score;
			}
			public void setScore(int score) {
				this.score = score;
			}
	    }
			
		 public enum Lens {
				LoisOpenda(1,"Lois Openda",60),Jimmycabot(2,"jimmy Cabot",55),
				StevenForten(3,"Steven Fortes",30),BriceSamba(4,"brice samba",70),
				KevinDanso(5,"Kevin Danso",65),
				IsmaelBoura(6,"Ismael Boura",15),Sekofofana(7,"Seko Fofana",40),
				Deiver(8,"Deiver",35),JeanOnana(9,"Jean Onana",75),RemyLabeau(10,"RemyLabeau",65),
				DavidCosta(11,"david Costa",55);
				
			 private int serialno;
			 private String name;
			 private int score;
				Lens(int serialno,String name ,int score){
					this.name=name;
			    	this.score=score;
			    	this.serialno=serialno;
				}
		
				public int getSerialno() {
					return serialno;
				}
				public void setSerialno(int serialno) {
					this.serialno = serialno;
				}
				public String getName() {
					return name;
				}
				public void setName(String name) {
					this.name = name;
				}
				public int getScore() {
					return score;
				}
				public void setScore(int score) {
					this.score = score;
				}
		}		
				
			public enum Monaco{
				YannLienard(1,"Yann Linnard",15),YllanOkou(2,"Yllan Okou",60),
				RubenAguilar(3,"Ruben Aguilar",55),ThomasDidillon(4,"Thomas Dillon",45),Ismail(5,"Ismail",70),
				MyronBoadu(6,"Myron Boadu",45),NazimBabai(7,"Nazim Babai",55),
				JeanLucas(8,"Jean Lucas",70),vanderson(9,"vanderson",75),KevinVolland(10,"Kevin Volland",65),
				Axeldisasi(11,"Axel disasi",80);
				
				private int serialno;
				private String name;
				private int score;
				Monaco(int serialno, String name ,int score){
					this.name=name;
			    	this.score=score;
			    	this.serialno=serialno;
				}

				public int getSerialno() {
					return serialno;
				}
				public void setSerialno(int serialno) {
					this.serialno = serialno;
				}
				public String getName() {
					return name;
				}
				public void setName(String name) {
					this.name = name;
				}
				public int getScore() {
					return score;
				}
				public void setScore(int score) {
					this.score = score;
				}
			}

}
