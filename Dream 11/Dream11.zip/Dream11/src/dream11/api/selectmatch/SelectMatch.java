package dream11.api.selectmatch;

import java.util.Scanner;

public class SelectMatch {
	static Date date=new Date();
	private static Scanner sc=new Scanner(System.in);
    public static int selectCricket()throws Exception
    {
    	System.out.println("Todays Matches Are....");
    	System.out.println(" 0) Exit");
    	System.out.println(" 1) Sunriser Hydrabad Vs Delhi Capital"+ "Match No 37 "+date.toString());
    	System.out.println(" 2) Royal Challenngers Vs Chennai SuperKing"+ "Match No 38 "+date.toString());
    	System.out.println("Enetr Your Chioise...");
    	return sc.nextInt();
    }
    public static int selectFootball()throws Exception
    {
    	System.out.println("Todays Matches Are....");
    	System.out.println(" 0) Exit");
    	System.out.println(" 1) Liverpool Vs NottinghamForest"+ "Match No 19 "+date.toString());
    	System.out.println(" 2) Lens Vs Monaco"+ "Match No 20 "+date.toString());
    	System.out.println("Enetr Your Chioise...");
    	return sc.nextInt();
    }
    public static int tournament()throws Exception {
    	System.out.println("Top Tournament Are...");
    	System.out.println(" 0) Exit ");
    	System.out.println(" 1) Indian Premier League IPL");
    	System.out.println(" 2) Football Premier League ");
    	System.out.println("Enter Your Choise..");
    	return sc.nextInt();
    }
}
