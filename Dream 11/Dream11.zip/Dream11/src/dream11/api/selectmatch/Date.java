package dream11.api.selectmatch;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Date {
    private int day;
    private int month;
    private int year;
    public Date()
    {
   	 Calendar cal=Calendar.getInstance();
   	 this.day=cal.get(Calendar.DAY_OF_MONTH);
   	 this.month=cal.get(Calendar.MONTH)+1;
   	 this.year=cal.get(Calendar.YEAR);
    }
    @Override 
    public String toString()
    {
   	 SimpleDateFormat simp=new SimpleDateFormat("dd/MMMM/yyyy");
   	 Calendar cal1=Calendar.getInstance();
   	 cal1.set(year, month-1, day);
   	 java.util.Date dt=cal1.getTime();
   	 return simp.format(dt);
   	 
    }
    
}
