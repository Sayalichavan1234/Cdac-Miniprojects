package dream11.api.login;

import java.util.Objects;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class NewUser {
	private String name;
	private String email;
	private String mobNumber;
	private String password;
	private int score;
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		NewUser other = (NewUser) obj;
		return Objects.equals(mobNumber, other.mobNumber) || Objects.equals(password, other.password);
	}
	@Override
	public int hashCode() {
		return Objects.hash(mobNumber, password);
	}
	@Override
	public String toString()
	{
		return String.format("Name: %-10s Mobile Number: %s-20 Email: %-20s",this.name,this.mobNumber,this.email);
	}
	
		
}
