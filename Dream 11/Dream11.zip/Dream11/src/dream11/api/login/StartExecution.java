package dream11.api.login;

import java.util.Scanner;

import dream11.api.contest.ContestEntry;
import dream11.api.creatteam.MakeTeam;

public class StartExecution extends Thread {
	private static Scanner sc=new Scanner(System.in);
	
	public static int choise() throws Exception
	{
		Thread th=new Thread();
		th.sleep(200);
		System.out.println("   $$-- Welocome To DREAM11 --$$   " );
		for(int i=0;i<20;i++)
		{
			System.out.print(". ");
			th.sleep(110);
		}
		System.out.println();
		System.out.println("0)   Exit ");
		System.out.println("1)   New User ");
		System.out.println("2)   Already Have Account ");
		System.out.println("=>  Enter Your Choise ");
		int choise=sc.nextInt();
		return choise;
	}
	private static String choiseChek(String choise) {
		String choise1 = null;
		if(!Character.isDigit(choise.charAt(0)))
		{
			System.out.println("Enter Right Choise ");
			choise1=sc.next();
			sc.nextLine();
			return StartExecution.choiseChek(choise1);
		}
		return choise1;
	}
	public static void main(String[] args) {
         int choise;
         try {
         while((choise=StartExecution.choise())!=0)
         {
        	switch(choise) 
        	{
        	case 1:
        		   AcceptRecord.addRecord();
        		   MakeTeam.makeTeam();
        		   break;
			case 2:
        		  AcceptRecord.cheakRecord();
        		  MakeTeam.makeTeam();
        		  break;
            default:
            	   System.out.println("Enter Right Choise ");break;
        	}
         }
         }
         catch(Exception sc)
         {
        	System.out.println( "Please Enter Right Choise");
         }
	}

}
