package dream11.api.login;

import java.util.ArrayList;
import java.util.Scanner;

public class AcceptRecord {
   public static ArrayList<NewUser> list=new ArrayList<>();
   private static Scanner scanner = new Scanner(System.in);
   public static void addRecord()
   {
	   
	   NewUser user=new NewUser();
       System.out.print("Enter your name: ");
       String name=scanner.next();
       scanner.nextLine();
       AcceptRecord.chekName(name);
       user.setName(name);
       name =null;
       System.out.print("Enter your email: ");
       String email=scanner.nextLine();
       AcceptRecord.chekEmail(email);
       user.setEmail(email);
       System.out.print("Enter your phone number: ");
       String phone=scanner.nextLine();
       AcceptRecord.chekPhone(phone);
       user.setMobNumber(phone);
       System.out.println("Set Password");
       user.setPassword(scanner.nextLine());  
       list.add(user);
	 	   
   }

   	private static String chekName(String name) {
   		if(!name.matches("[a-zA-Z]+"))
			{
		      System.out.println("Enter Valid name");
		      String name1=scanner.nextLine();		      
		      return AcceptRecord.chekName(name1);
			}
	return null;
   	}
   	private static String chekEmail(String email) {
   	 String email1=null;
   		if(!email.matches("^[a-zA-Z0-9_+&*-]+(?:\\."+"[a-zA-Z0-9_+&*-]+)*@"+"(?:[a-zA-Z0-9-]+\\.)+[a-z"+"A-Z]{2,7}$"))
   			{
   			  System.out.println("Enter Valid Email");
   			  email1=scanner.next();		
   			  scanner.nextLine();
   			  return AcceptRecord.chekName(email1);
   			}
   	return email1;
   	}
   	private static String  chekPhone(String phone) {
   		if(!phone.matches("\\d{10}$"))
   			{
   			  if(!(phone.length()==10))
   					{
   				  	System.out.println("Enter Valid Phone Number");
   				  	String phone1=scanner.nextLine();
   				  	return AcceptRecord.chekPhone(phone1);		
   					}
   			}
	return phone;
   	}
   public static void cheakRecord()
   {
	   System.out.println(list.toString());
	   NewUser user=new NewUser();
	   System.out.println("Enter Your Phone Number");
	   String phone=scanner.nextLine();
	   user.setMobNumber(phone);
	   System.out.println("Enter Your Passoword");
	   String password=scanner.nextLine();
	   user.setPassword(password);
	   if(list.contains(user))
	      {
		   int index=list.indexOf(user);
		   String name=list.get(index).getName();
		   System.out.println("Welcome To Dream11 "+name);
           }else
    		   System.out.println("Account Not Found");
   }
}
