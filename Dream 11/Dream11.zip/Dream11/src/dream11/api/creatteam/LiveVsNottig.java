package dream11.api.creatteam;

import java.util.Scanner;


import dream11.api.selectmatch.FootBallTeams.Liverpool;
import dream11.api.selectmatch.FootBallTeams.NottinghamForest;

public class LiveVsNottig implements InterFaceTeam { 
		private static Liverpool [] live=Liverpool.values();
		private static NottinghamForest[] notting=NottinghamForest.values();
		private static Scanner sc=new Scanner(System.in);
		public enum Team3{
			Player1(1,"Name","Designation",0),Player2(2,"Name","Designation",0),Player3(2,"Name","Designation",0),
			Player4(3,"Name","Designation",0),Player5(5,"Name","Designation",0),Player6(6,"Name","Designation",0),
			Player7(7,"Name","Designation",0),Player8(8,"Name","Designation",0),Player9(9,"Name","Designation",0),
			Player10(10,"Name","Designation",0),Player11(11,"Name","Designation",0);
	        private int srno;
	        private String name;
	        private String designation;
	        private int score ;
	        public int getScore() {
				return score;
			}

			public void setScore(int score) {
				this.score = score;
			}
			public int getSrno() {
				return srno;
			}

			public void setSrno(int srno) {
				this.srno = srno;
			}

			public String getName() {
				return name;
			}

			public void setName(String name) {
				this.name = name;
			}

			public String getDesignation() {
				return designation;
			}

			public void setDesignation(String designation) {
				this.designation = designation;
			}

			Team3(int i, String string, String string2,int score) {
				this.srno=i;
				this.name=string;
				this.designation=string2;
				this.score=score;
			}

		}
		private static Team3[] team3=Team3.values();
		public static int totalScore3=0;
		@Override
		public int creatTeam() {
			try {
				int j=12;
			System.out.println("Player List is..");
			for(int i=0;i<team3.length;i++)
			{
				System.out.printf("%-5d%-20s%-5d%-30s \n",(i+1),Liverpool.values()[i].getName(),j,NottinghamForest.values()[i].getName());
				j++;
			}
			System.out.println("For Selecting Select Proper Index ");
		  	System.out.println(" Select Your Captain ");
		  	int cap=sc.nextInt();
		  	if(cap<=11) {
		  	Team3.values()[0].setName(Liverpool.values()[cap-1].getName());
		  	Team3.values()[0].setDesignation("Captain");
		  	Team3.values()[0].setScore(Liverpool.values()[cap-1].getScore());
		  	
		  	}if(cap>11&& cap<23)
		  	{
		  		Team3.values()[0].setName(NottinghamForest.values()[cap-12].getName());
			  	Team3.values()[0].setDesignation("Captain");
			  	Team3.values()[0].setScore(NottinghamForest.values()[cap-12].getScore());
		  	}
		    System.out.println(" Select Your Goal-Keeper ");	
		  	int cap1=sc.nextInt();
		  	if(cap1<=11) {
		  	Team3.values()[1].setName(Liverpool.values()[cap1-1].getName());
		  	Team3.values()[1].setDesignation("Goal-Keeper");
		  	Team3.values()[1].setScore(Liverpool.values()[cap1-1].getScore());
		  	}if(cap1>11&& cap1<23)
		  	{
		  		Team3.values()[1].setName(NottinghamForest.values()[cap1-12].getName());
			  	Team3.values()[1].setDesignation("Goal-Keeper");
			  	Team3.values()[1].setScore(NottinghamForest.values()[cap1-12].getScore());
		  	}
		  	for(int i=0;i<9;i++)
		  	{
		  		System.out.println("Select Youre "+(i+2)+" Player ");
		  		int player=sc.nextInt();
		  		if(player<=11) {
		  		Team3.values()[i+2].setName(Liverpool.values()[player-1].getName());
			  	Team3.values()[i+2].setDesignation("O-Player");
			  	Team3.values()[i+2].setScore(Liverpool.values()[player-1].getScore());
		  		}if(player>11&& player<23) {
		  			Team3.values()[i+2].setName(NottinghamForest.values()[player-12].getName());
				  	Team3.values()[i+2].setDesignation("O-Player");
				  	Team3.values()[i+2].setScore(NottinghamForest.values()[player-12].getScore());
				  	
		  		}
		  	}
			}
			catch(Exception sc)
			{
				System.out.println("Enter Right Choise or Restart Program..");
			}
			finally {
				System.out.println("Your Team is ");
				System.out.println();
			for(int i=0;i<team3.length;i++)
			{
				System.out.printf("%-5d%-20s%-20s\n",Team3.values()[i].getSrno(),Team3.values()[i].getName(),Team3.values()[i].getDesignation());
				totalScore3=totalScore3+Team3.values()[i].getScore();
			}
			}
			
			return 0;
		
	}

}
