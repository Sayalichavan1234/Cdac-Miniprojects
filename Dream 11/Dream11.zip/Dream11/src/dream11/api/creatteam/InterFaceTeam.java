package dream11.api.creatteam;

public interface InterFaceTeam {
	int creatTeam();

}
