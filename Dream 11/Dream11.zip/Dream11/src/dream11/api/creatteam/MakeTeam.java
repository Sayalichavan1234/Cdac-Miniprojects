package dream11.api.creatteam;

import dream11.api.contest.ContestEntry;
import dream11.api.selectmatch.CricketTeams;
import dream11.api.selectmatch.SelectMatch;

public class MakeTeam {
	 
	public static void makeTeam() throws Exception
	{
		int choise;
		int choise1;
		InterFaceTeam teamSel=null;
		while((choise=SelectMatch.tournament())!=0)
		{
			
			switch(choise)
			{
			case 1:
				while((choise1=SelectMatch.selectCricket())!=0) {
					switch(choise1)
					{
					case 1:
						  teamSel=new DehliVsHyd();
					      ContestEntry.runContest(teamSel);
					      break;
					case 2:
						 teamSel=new RcbVsCsk();
						 ContestEntry.runContest(teamSel);
					     break;
				    default: System.out.println("Enter Right Right Choise");break;
					}
				}
				break;
			case 2:
				while((choise1=SelectMatch.selectCricket())!=0) {
					switch(choise1)
					{
					case 1:
						  teamSel=new LiveVsNottig();
						  CricketTeams obj=new CricketTeams();
					      ContestEntry.runContest(teamSel);
					      break;
					case 2:
						teamSel=new LiveVsNottig();
						  ContestEntry.runContest(teamSel);
					      break;
					default: System.out.println("Enter Right Right Choise");break;
					}
				}break;
				default:System.out.println("Enter Right Right Choise");break;		
				   
			}
		}
	}
}
