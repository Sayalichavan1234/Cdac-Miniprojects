package dream11.api.contest;

import dream11.api.login.NewUser;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@AllArgsConstructor
@Data
@NoArgsConstructor
public class ContestSummary {
	private String NameOfContest;
	private NewUser user;
	private int moneyinvest;
	@Override 
	public String toString()
	{
		return String.format("Contest Name: %-10s User Information : %-20s\n Total Money Invest: %-5d",this.user,this.NameOfContest,this.moneyinvest);
	}
}
