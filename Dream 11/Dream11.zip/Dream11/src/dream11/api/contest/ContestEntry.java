package dream11.api.contest;

import java.util.ArrayList;
import java.util.Scanner;

import dream11.api.creatteam.InterFaceTeam;
import dream11.api.login.AcceptRecord;
import dream11.api.login.NewUser;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

public class ContestEntry {
	
	public enum DiscountedEntry
	{
		Contest1(1,"35 Crores",4,100),Contest2(2,"10 Crores",3,100),
		Contest3(3,"1.50 Crores",75,100);
		@Getter @Setter int srno;
		@Getter @Setter String poolName;
		@Getter @Setter int entryfee;
		@Getter @Setter int participient;
		DiscountedEntry(int i, String string, int j, int k) {
			this.srno=i;
			this.poolName=string;
			this.entryfee=j;
			this.participient=k;
			
		}
	}
	public enum OnlyForBeginers{
		Contest1(1,"49",17,100);
		@Getter @Setter int srno;
		@Getter @Setter String poolName;
		@Getter @Setter int entryfee;
		@Getter @Setter int participient;
       OnlyForBeginers(int i, String string, int j, int k) {
    	   this.srno=i;
			this.poolName=string;
			this.entryfee=j;
			this.participient=k;
			
			
		}

	}
	public enum Highentry{
		Contest1(1,"29350",10999,100),Contest2(2,"26700",9999,100),
		Contest3(3,"15222",8555,100);
		@Getter @Setter int srno;
		Highentry(int i, String string, int j, int k) {
			this.srno=i;
			this.poolName=string;
			this.entryfee=j;
			this.participient=k;
			
		}
		@Getter @Setter String poolName;
		@Getter @Setter int entryfee;
		@Getter @Setter int participient;
		
		
	}
	private static DiscountedEntry[] entry1=DiscountedEntry.values();
	private static OnlyForBeginers[] entry2=OnlyForBeginers.values();
	private static Highentry[] entry3=Highentry.values();
	private static Scanner sc=new Scanner(System.in);
	private static ContestSummary summary=new ContestSummary();
	static Thread th1=new Thread();
	public static ArrayList<ContestSummary> contestList=new ArrayList<>();
	public static NewUser currentUser()
	{
		NewUser user=new NewUser();
		System.out.println("Enter Your password ");
  	    String pass=sc.next();
  	    sc.nextLine();
		user.setPassword(pass);
		if(AcceptRecord.list.contains(user))
				{
			        int index=AcceptRecord.list.indexOf(user);
			        return AcceptRecord.list.get(index);
				}
		else
			System.out.println("Wrong Password ");
		return null;	
	}
	public static int listOfContest() throws Exception
	{
		th1.sleep(0);
		System.out.println("Please Select the Contest..");
		System.out.println("0) Exit  ");
		System.out.println("1)Discounted (Entry Stating Form 3 Rs)");
		System.out.println("2)Only For Beiginers (Entry Starting Form 49 Rs)");
		System.out.println("3)High entry= High Rewards(Entry Starting Form 8555 Rs)");
		System.out.println("Enter Your Choise ");
		return sc.nextInt();
	}
	public static int runContest(InterFaceTeam team) throws Exception
	{
		int choise;
		int choise1;
		
		while((choise=ContestEntry.listOfContest())!=0)
		{
			switch(choise)
			{
			case 1: 
				  while((choise1=ContestEntry.DiscountedEntry())!=0)
                     {
	                      switch(choise1)
	                      {
	                      case 1:
	                    	  summary.setNameOfContest(DiscountedEntry.values()[choise1-1].getPoolName());                           
	                    	  summary.setMoneyinvest(DiscountedEntry.values()[choise1-1].entryfee);
	                    	  summary.setUser(ContestEntry.currentUser());
	                    	  DiscountedEntry.values()[choise1-1].setParticipient( DiscountedEntry.values()[choise1-1].getParticipient()-1);
	                    	  team.creatTeam();
	                    	  break;
	                      case 2:
	                    	  summary.setNameOfContest(DiscountedEntry.values()[choise1-1].poolName);
	                    	  summary.setMoneyinvest(DiscountedEntry.values()[choise1-1].entryfee);
	                    	  summary.setUser(ContestEntry.currentUser());
	                    	  DiscountedEntry.values()[choise1-1].setParticipient( DiscountedEntry.values()[choise1-1].getParticipient()-1);
	                    	  team.creatTeam();
	                    	  break;
	                      case 3:
	                    	  summary.setNameOfContest(DiscountedEntry.values()[choise1-1].poolName);
	                    	  summary.setMoneyinvest(DiscountedEntry.values()[choise1-1].entryfee);
	                    	  summary.setUser(ContestEntry.currentUser());
	                    	  DiscountedEntry.values()[choise1-1].setParticipient( DiscountedEntry.values()[choise1-1].getParticipient()-1);
	                    	  team.creatTeam();
	                    	  break;
	                     default:
	                    	 System.out.println("Contest Not Found");
	                    	  
	                      }
                     }
				  
				  break;
			case 2:
				while((choise1=ContestEntry.OnlyForBeigener())!=0)
                {
                     switch(choise1)
                     {
                     case 1:
                   	  summary.setNameOfContest(OnlyForBeginers.values()[choise1-1].poolName);
                   	  summary.setMoneyinvest(OnlyForBeginers.values()[choise1-1].entryfee);
                   	  summary.setUser(ContestEntry.currentUser());
                   	  OnlyForBeginers.values()[choise1-1].setParticipient( OnlyForBeginers.values()[choise1-1].getParticipient()-1);
                    	team.creatTeam();
                   	  break;
                    default:
                   	 System.out.println("Contest Not Found");break;
                   	  
                     }
                }break;
			case 3:
				while((choise1=ContestEntry.highEntry())!=0)
                {
                     switch(choise1)
                     {
                     case 1:
                   	  summary.setNameOfContest(Highentry.values()[choise1-1].poolName);
                   	  summary.setMoneyinvest(Highentry.values()[choise1-1].entryfee);
                   	  summary.setUser(ContestEntry.currentUser());
                   	  Highentry.values()[choise1-1].setParticipient( Highentry.values()[choise1-1].getParticipient()-1);
                    	team.creatTeam();
                   	  break;
                     case 2:
                   	  summary.setNameOfContest(Highentry.values()[choise1-1].poolName);
                   	  summary.setMoneyinvest(Highentry.values()[choise1-1].entryfee);
                   	  summary.setUser(ContestEntry.currentUser());
                   	  Highentry.values()[choise1-1].setParticipient( Highentry.values()[choise1-1].getParticipient()-1);
                    	team.creatTeam();
                   	  break;
                     case 3:
                   	  summary.setNameOfContest(Highentry.values()[choise1-1].poolName);
                   	  summary.setMoneyinvest(Highentry.values()[choise1-1].entryfee);
                   	  summary.setUser(ContestEntry.currentUser());
                   	  Highentry.values()[choise1-1].setParticipient( Highentry.values()[choise1-1].getParticipient()-1);
                   	team.creatTeam();
                   	  break;
                    default:
                   	 System.out.println("Contest Not Found");break;
                   	  
                     }
                }
				break;
			}
		}		
		contestList.add(summary); 
		return 0;
	}
	private static int highEntry() throws Exception{
		System.out.println("0) Exist ");
		System.out.println("1) Max Pool Prize 29,350RS Entree Fee 10,999RS");
		System.out.println("2) Max Pool Prize 26,700Rs Entree Fee 9,999Rs ");
		System.out.println("3) Max Pool Prize 15,222Rs Entree Fee 8,555Rs ");
		System.out.println("Enter Your Choise ");
		
		return sc.nextInt();
	}
	private static int OnlyForBeigener()throws Exception {
		System.out.println("0) Exist ");
		System.out.println("1) Max Pool Prize 49RS Entree Fee 17RS");
		System.out.println("Enter Your Choise ");
		return sc.nextInt();
	}
	private static int DiscountedEntry()throws Exception{
		System.out.println("0) Exist ");
		System.out.println("1) Max Pool Prize 35 CRORES RS Entree Fee 4RS");
		System.out.println("2) Max Pool Prize 10 CRORES Rs Entree Fee 3Rs ");
		System.out.println("3) Max Pool Prize 1.50 CRORES RS Entree Fee 75Rs ");
		System.out.println("Enter Your Choise ");	
		return sc.nextInt();
	
		
	}

}
